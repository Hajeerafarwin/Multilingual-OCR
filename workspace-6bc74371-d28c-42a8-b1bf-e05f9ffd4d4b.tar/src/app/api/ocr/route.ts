import ZAI from 'z-ai-web-dev-sdk';
import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { image } = body;

    if (!image) {
      return NextResponse.json(
        { error: 'No image provided' },
        { status: 400 }
      );
    }

    // Initialize ZAI SDK
    const zai = await ZAI.create();

    // Use VLM to extract text from the image
    const response = await zai.chat.completions.createVision({
      messages: [
        {
          role: 'user',
          content: [
            {
              type: 'text',
              text: 'Extract all text from this image. Preserve the layout and formatting as much as possible. Output only the extracted text content without any additional explanations or descriptions. If there is no text in the image, respond with "No text detected in this image."'
            },
            {
              type: 'image_url',
              image_url: {
                url: image // This should be a data URL like: data:image/png;base64,xxxxx
              }
            }
          ]
        }
      ],
      thinking: { type: 'disabled' }
    });

    const extractedText = response.choices[0]?.message?.content || '';

    return NextResponse.json({
      success: true,
      text: extractedText
    });

  } catch (error: any) {
    console.error('OCR Error:', error);
    return NextResponse.json(
      { error: error.message || 'Failed to process image' },
      { status: 500 }
    );
  }
}
