import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "OCR.Z - Free AI-Powered Text Extraction Tool",
  description: "Extract text from images instantly with our free OCR tool. Powered by GLM-OCR AI for accurate text recognition from screenshots, photos, documents, and handwritten notes.",
  keywords: ["OCR", "text extraction", "image to text", "GLM-OCR", "AI OCR", "free OCR", "optical character recognition"],
  authors: [{ name: "OCR.Z Team" }],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
  openGraph: {
    title: "OCR.Z - Free AI-Powered Text Extraction",
    description: "Extract text from images instantly with our free OCR tool powered by GLM-OCR",
    url: "https://ocr.z.ai",
    siteName: "OCR.Z",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "OCR.Z - Free AI-Powered Text Extraction",
    description: "Extract text from images instantly with our free OCR tool powered by GLM-OCR",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
