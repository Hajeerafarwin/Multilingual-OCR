# GITHUB UPLOAD GUIDE - OCR.Z Project

## Quick Upload Commands

Run these commands in your terminal:

```bash
# 1. Navigate to project
cd /home/z/my-project

# 2. Initialize git
git init

# 3. Add all files
git add .

# 4. Commit
git commit -m "Initial commit: OCR.Z - AI-Powered Text Extraction Tool"

# 5. Create GitHub repository first at https://github.com/new
# Then add remote (replace YOUR_USERNAME)
git remote add origin https://github.com/YOUR_USERNAME/ocr-z.git

# 6. Push to GitHub
git branch -M main
git push -u origin main
```

## Deploy to Vercel (After GitHub Upload)

1. Go to https://vercel.com
2. Click "Add New Project"
3. Import your GitHub repository
4. Click "Deploy"
5. Done! Your OCR app will be live!

## Project Structure

```
ocr-z/
├── .github/
│   └── workflows/
│       └── deploy.yml          # GitHub Actions deployment
├── public/
│   ├── logo.svg
│   └── robots.txt
├── src/
│   ├── app/
│   │   ├── api/
│   │   │   ├── ocr/
│   │   │   │   └── route.ts    # OCR API endpoint
│   │   │   └── route.ts
│   │   ├── globals.css
│   │   ├── layout.tsx
│   │   └── page.tsx            # Main OCR page
│   ├── components/ui/          # UI components (shadcn)
│   ├── hooks/
│   └── lib/
├── .gitignore
├── components.json
├── eslint.config.mjs
├── next.config.ts
├── package.json
├── postcss.config.mjs
├── README.md
├── tailwind.config.ts
├── tsconfig.json
└── vercel.json
```

## Important Notes

1. **Do NOT upload**: node_modules, .next, .env files (they are in .gitignore)
2. **Required for deployment**: Vercel account (free)
3. **No environment variables needed**: z-ai-web-dev-sdk is pre-configured
