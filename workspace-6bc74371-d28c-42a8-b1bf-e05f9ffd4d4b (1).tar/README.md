# OCR.Z - AI-Powered Text Extraction

A free, fast, and accurate OCR tool powered by GLM-OCR AI for extracting text from images.

![OCR.Z Screenshot](https://via.placeholder.com/800x400?text=OCR.Z+Screenshot)

## ✨ Features

- 🖼️ **Multi-format support**: PNG, JPG, JPEG, WEBP, GIF, BMP
- ⚡ **Lightning fast**: AI-powered text extraction in seconds
- 🎯 **High accuracy**: State-of-the-art GLM-OCR model
- 📋 **Easy export**: Copy to clipboard or download as text file
- 📱 **Responsive**: Works on desktop and mobile devices
- 🔒 **Privacy-first**: No data stored on servers

## 🛠️ Tech Stack

- **Framework**: Next.js 16 with App Router
- **Styling**: Tailwind CSS 4 + shadcn/ui
- **AI Engine**: GLM-OCR via z-ai-web-dev-sdk
- **Language**: TypeScript
- **Runtime**: Bun

## 🚀 Quick Start

### Prerequisites

- Node.js 24+ or Bun runtime
- npm, yarn, or bun package manager

### Installation

```bash
# Clone the repository
git clone <your-repo-url>
cd ocr-z

# Install dependencies
bun install

# Run development server
bun run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

## 📦 Deployment

### Option 1: Vercel (Recommended) ⭐

Vercel is the best platform for Next.js applications with API routes.

#### Quick Deploy

1. Push your code to GitHub
2. Go to [vercel.com](https://vercel.com)
3. Click "Import Project" → Select your repository
4. Vercel auto-detects Next.js and deploys!

#### Deploy Button

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https://github.com/your-username/ocr-z)

### Option 2: GitHub Actions + Vercel

The repository includes a GitHub Actions workflow for automated deployment.

1. **Get Vercel tokens**:
   - Go to [Vercel Account Settings](https://vercel.com/account/tokens)
   - Create a new token

2. **Get Vercel IDs**:
   ```bash
   # Install Vercel CLI
   bun add -g vercel

   # Link project
   vercel link

   # Check .vercel/project.json for orgId and projectId
   ```

3. **Add GitHub Secrets**:
   - `VERCEL_TOKEN`: Your Vercel token
   - `VERCEL_ORG_ID`: Your organization ID
   - `VERCEL_PROJECT_ID`: Your project ID

4. **Push to deploy**:
   ```bash
   git push origin main
   ```

### Option 3: Docker

```bash
# Build the Docker image
docker build -t ocr-z .

# Run the container
docker run -p 3000:3000 ocr-z
```

### Option 4: Self-hosted

```bash
# Build for production
bun run build

# Start the server
bun run start
```

## 🔧 Environment Variables

No environment variables required! The `z-ai-web-dev-sdk` is pre-configured.

## 📖 API Reference

### POST /api/ocr

Extract text from an image.

**Request:**
```json
{
  "image": "data:image/png;base64,..."
}
```

**Response:**
```json
{
  "success": true,
  "text": "Extracted text content..."
}
```

**Example:**
```bash
curl -X POST http://localhost:3000/api/ocr \
  -H "Content-Type: application/json" \
  -d '{"image": "data:image/png;base64,iVBORw0KGgo..."}'
```

## 📁 Project Structure

```
src/
├── app/
│   ├── page.tsx          # Main OCR page
│   ├── layout.tsx        # Root layout
│   ├── globals.css       # Global styles
│   └── api/
│       └── ocr/
│           └── route.ts  # OCR API endpoint
├── components/
│   └── ui/               # shadcn/ui components
├── hooks/                # Custom React hooks
└── lib/                  # Utility functions
```

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## 📄 License

MIT License

---

Built with ❤️ using [Z.ai](https://chat.z.ai) - AI-Powered Development Platform
