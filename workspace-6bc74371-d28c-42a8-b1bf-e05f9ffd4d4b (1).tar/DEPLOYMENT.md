# OCR.Z - AI-Powered Text Extraction

A free, fast, and accurate OCR tool powered by GLM-OCR AI for extracting text from images.

## Features

- 🖼️ **Multi-format support**: PNG, JPG, JPEG, WEBP, GIF, BMP
- ⚡ **Lightning fast**: AI-powered text extraction in seconds
- 🎯 **High accuracy**: State-of-the-art GLM-OCR model
- 📋 **Easy export**: Copy to clipboard or download as text file
- 📱 **Responsive**: Works on desktop and mobile devices

## Tech Stack

- **Framework**: Next.js 16 with App Router
- **Styling**: Tailwind CSS 4 + shadcn/ui
- **AI Engine**: GLM-OCR via z-ai-web-dev-sdk
- **Language**: TypeScript

## Getting Started

### Prerequisites

- Node.js 24+ or Bun
- npm, yarn, or bun

### Installation

```bash
# Clone the repository
git clone <your-repo-url>
cd ocr-z

# Install dependencies
bun install

# Run development server
bun run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

## Deployment

### Option 1: Vercel (Recommended)

Vercel is the best platform for Next.js applications with API routes.

#### Automatic Deployment

1. Push your code to GitHub
2. Go to [vercel.com](https://vercel.com)
3. Import your GitHub repository
4. Vercel will automatically deploy on every push

#### Manual Deployment with GitHub Actions

1. Get your Vercel tokens:
   - Go to [Vercel Account Settings](https://vercel.com/account/tokens)
   - Create a new token

2. Get your Vercel IDs:
   - Run `vercel link` in your project
   - Check `.vercel/project.json` for `orgId` and `projectId`

3. Add secrets to your GitHub repository:
   - `VERCEL_TOKEN`: Your Vercel token
   - `VERCEL_ORG_ID`: Your organization ID
   - `VERCEL_PROJECT_ID`: Your project ID

4. Push to main branch to trigger deployment

### Option 2: Docker

```bash
# Build the Docker image
docker build -t ocr-z .

# Run the container
docker run -p 3000:3000 ocr-z
```

### Option 3: Self-hosted

```bash
# Build for production
bun run build

# Start the server
bun run start
```

## Environment Variables

No environment variables are required. The `z-ai-web-dev-sdk` is pre-configured.

## API Reference

### POST /api/ocr

Extract text from an image.

**Request Body:**
```json
{
  "image": "data:image/png;base64,..."
}
```

**Response:**
```json
{
  "success": true,
  "text": "Extracted text content..."
}
```

## License

MIT License
